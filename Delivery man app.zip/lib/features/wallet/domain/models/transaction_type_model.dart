class TransactionTypeModel{
  String icon;
  String title;
  double? amount;
  int index;
  TransactionTypeModel(this.icon, this.title, this.amount, this.index);
}