
abstract class OnboardServiceInterface {
  Future<dynamic> getOnBoardingList();

}