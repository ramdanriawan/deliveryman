class OnBoardingModel{
  String imageUrl;
  String title;
  String description;

  OnBoardingModel(this.imageUrl, this.title, this.description);
}