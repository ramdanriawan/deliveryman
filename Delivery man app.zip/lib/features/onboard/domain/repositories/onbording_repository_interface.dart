import 'package:fashion24_deliveryman/interface/repository_interface.dart';

abstract class OnboardRepositoryInterface implements RepositoryInterface{}