import 'package:fashion24_deliveryman/interface/repository_interface.dart';

abstract class EmergencyContactRepositoryInterface implements RepositoryInterface {}