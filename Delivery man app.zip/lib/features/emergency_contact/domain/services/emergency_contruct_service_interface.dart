

abstract class EmergencyContactServiceInterface{
  Future<dynamic> getEmergencyContactList();
}