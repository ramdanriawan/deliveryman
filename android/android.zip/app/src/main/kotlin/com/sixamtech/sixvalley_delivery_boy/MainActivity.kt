package com.bikinaplikasi.fashion24.deliveryman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}